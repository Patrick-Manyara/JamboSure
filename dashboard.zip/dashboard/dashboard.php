<?php
$page        = 'dashboard';
$header_name = 'Home';

//  require_once '../path.php';
require_once 'header.php';


?>


<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                  
                </div>
            </div>
        </div>


    </div>


</div>
<!-- / Content -->

<!-- Page JS -->


<?php include_once 'footer.php'; ?> 