<?php
include_once 'header.php';

?>


	<section id="in-error" class="in-error-section">
		<div class="container">
			<div class="in-error-content text-center">
				<div class="in-error-img">
					<img src="assets/img/about/404.png" alt="">
				</div>
				<div class="in-error-text headline pera-content">
					<h2>Page Not Found!</h2>
					<p>We are sorry to say that our page is not found!</p>
					<div class="in-btn-1">
						<a href="index">Go Home</a>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php include_once 'footer.php'; ?>