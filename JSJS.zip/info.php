<?php
$page = 'create account';
include_once 'header.php';

$sql = "SELECT * FROM policy WHERE device_id = '$_COOKIE[device]' ORDER BY policy_date_created DESC ";
$policy = select_rows($sql)[0];

if ($policy['prod_category'] == 'third_party') {
    if ($policy['cover_duration'] == '12') {
        $newPrice = get_by_id('prod', $policy['product_id'])['prod_twelve_fee'];
    } else {
        $newPrice = get_by_id('prod', $policy['product_id'])['prod_one_fee'];
    }
} else {
    $totalBenefit = 0;

    $benefits = explode(",", $policy['policy_benefits']);

    foreach ($benefits as $ben) {
        $sql = "SELECT * FROM benefit WHERE benefit_id = '$ben' ";
        $benefit = select_rows($sql)[0];

        if ($benefit['benefit_mode'] == 'rate') {
            // If it's a rate, multiply the percentage to the post price
            $totalBenefit += $benefit['benefit_rate'] / 100 * $policy['first_price'];
        } elseif ($benefit['benefit_mode'] == 'price') {
            // If it's a price, add the block figure to the total benefit
            $totalBenefit += $benefit['benefit_price'];
        }
    }

    $MATH = (6 / 100 * $policy['policy_value']);
    $newPr = (0.75 / 100 * $policy['policy_value']) + $MATH;
    $lev = (0.45 / 100 * $newPr) + 40 + +$newPr;


    // Add the total benefit to the original price
    $newPrice2 = $totalBenefit + $policy['first_price'];

    $levies = get_by_column('levy', 'product_id', security('product_id'), 'yes');

    $totalBenefit2 = 0;
    foreach ($levies as $levy) {

        if ($levy['levy_mode'] == 'rate') {
            // If it's a rate, multiply the percentage to the post price
            $totalBenefit2 += $levy['levy_rate'] / 100 * $newPrice2;
        } elseif ($levy['levy_mode'] == 'price') {
            // If it's a price, add the block figure to the total benefit
            $totalBenefit2 += $levy['levy_price'];
        }
    }

    $newPrice = $totalBenefit2 + $totalBenefit + $policy['first_price'];

    $levyTotal = 0;


    $levyTotal = 0.45 / 100 * $newPrice;


    $officialPrice = $levyTotal + $newPrice;

    if (isset($_POST['benefits']) && is_array($_POST['benefits'])) {
        $benefitsString = implode(',', $_POST['benefits']);
    }
}
?>

<head>
    <script type="text/javascript" src="https://checkoutv3.jambopay.com/sdk/checkout-sdk.js"></script>
    <link rel="stylesheet" href="https://checkout.jambopay.com/jambopay-styles-checkout.min.css" />
</head>


<section id="in-breadcrumb" class="in-breadcrumb-section">
    <div class="in-breadcrumb-content position-relative" data-background="assets/img/new/header.png">
        <div class="background_overlay"></div>
        <div class="container">
            <div class="in-breadcrumb-title-content position-relative headline ul-li">
                <span> </span>
                <h2>Home / <?= ucwords($page) ?></h2>
            </div>
        </div>
    </div>
</section>


<section id="in-about-1" class="in-about-section-1 about-page-about position-relative">
    <div class="container">
        <div class="row">

            <div class="col-lg-8">
                <?php
                if (!isset($_SESSION['user_login'])) { ?>
                    <form method="POST" action="<?= model_url ?>user_login&from=info">
                        <div class="form-group">
                            <input type="email" placeholder="Email" name="user_email" class="LoginInput" />
                        </div>
                        <div class="form-group">
                            <input type="password" placeholder="Password" name="user_password" class="LoginInput" />
                        </div>
                        <div class="JusAround">
                            <div class="DeeFlex MarginTop">

                                <a href="register.php?payment">
                                    Don't have an account?
                                    <span style="color:<?= $maincolor ?>;">
                                        Register
                                    </span>
                                </a>
                            </div>
                            <div>
                                <p class="Forgot">
                                    Forgot Password
                                </p>
                            </div>
                        </div>

                        <div class="MarginTop">
                            <button type="submit" class="BlueBtn">
                                Continue
                            </button>
                        </div>
                    </form>
                <?php
                } else { ?>
                    <div class="RegisterCard">
                        <div id="progress">
                            <div id="progress-bar"></div>
                            <ul id="progress-num">
                                <li class="step active">1</li>
                                <li class="step">2</li>
                            </ul>
                        </div>
                        <div class="PersonalDetails">
                            <form id="MyForm">


                                <div class="PersonalForm">

                                    <div class="row PersVeh" id="personal_form">
                                        <h2 style="font-size: 32px;font-style: normal;font-weight: 700;">
                                            Personal Details
                                        </h2>
                                        <p>
                                            <b>
                                                Personal information
                                            </b>
                                        </p>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" disabled placeholder="Full Name" id="Name" name="full_name" value="<?= $user['user_name'] ?>" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="email" disabled placeholder="Email Address" name="email" value="<?= $user['user_email'] ?>" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" placeholder="Phone Number" name="phone" value="<?= $user['user_phone'] ?>" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <select name="user_gender" class="form-select form-control LoginInput" required aria-label="Default select example">
                                                <option selected>Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" disabled value="<?= $user['user_dob'] ?>" class="form-control LoginInput" placeholder="Date of Birth" aria-label="Date of Birth">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="number" name="user_passport" required value="<?= $user['user_passport'] ?>" placeholder="ID Number" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" name="user_kra" required value="<?= $user['user_kra'] ?>" placeholder="KRA PIN" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label class="custom-file-upload">
                                                    <input required type="file" name="national" />
                                                    <i class="far fa-cloud-upload" style="color:<?= $secondarycolor ?>"></i> Upload National ID
                                                </label>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row PersVeh" id="vehicle_form">
                                        <h2 style="font-size: 32px;font-style: normal;font-weight: 700;">
                                            Vehicle Details
                                        </h2>
                                        <p>
                                            <b>
                                                Vehicle information
                                            </b>
                                        </p>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input required type="text" name="vehicle_reg" placeholder="Vehicle regitrstion  Number" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="email" disabled name="vehicle_make" value="<?= $policy['policy_make'] ?>" placeholder="Make" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" disabled name="vehicle_model" value="<?= $policy['policy_model'] ?>" placeholder="Model" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" disabled name="vehicle_year" value="<?= $policy['policy_year'] ?>" placeholder="Year of manufacture" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" disabled name="vehicle_value" value="<?= $policy['policy_value'] ?>" placeholder="Estimated value in Ksh" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <select required class="form-select form-control LoginInput" name="capacity" aria-label="Default select example">
                                                <option selected>Seating Capacity</option>
                                                <option value="Saloon">Saloon</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input required type="text" placeholder="Engine Capacity" name="engine" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input required type="text" placeholder="Chasis Number" name="vehicle_chasis" class="LoginInput" />
                                            </div>
                                        </div>

                                        <div class="col-lg-12 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label class="custom-file-upload">
                                                    <input required type="file" name="logbook" />
                                                    <i class="far fa-cloud-upload" style="color:<?= $secondarycolor ?>"></i> Upload vehicle Log book
                                                </label>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="DeeEnd">
                            <button id="progress-prev" class="btn InputBtnClear2" disabled>Prev</button>
                            <button id="progress-next" class="btn InputBtn">Proceed</button>
                        </div>
                    </div>
                <?php

                }
                ?>

            </div>
            <div class="col-lg-4">
                <div class="SummaryBox">
                    <div class="DeeFlex">
                        <h3 style="color: <?= $secondarycolor ?>;">
                            Quote Summary
                        </h3>
                    </div>
                    <div style="height: 100%;">
                        <?php
                        if ($policy['prod_category'] != 'third_party') { ?>


                            <div class="row">
                                <div class="col-6">
                                    <p class="LeftSideText">Value</p>
                                </div>
                                <div class="col-6">
                                    <p class="RightSideText"><?= $policy['policy_value'] ?></p>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <p class="LeftSideText">Basic Premium</p>
                                </div>
                                <div class="col-6">
                                    <p class="RightSideText"><?= $policy['first_price'] ?></p>
                                </div>
                            </div>

                            <?php
                            foreach ($benefits as $ben) {
                                $sql = "SELECT * FROM benefit WHERE benefit_id = '$ben' ";
                                $benefit = select_rows($sql)[0];

                                if ($benefit['benefit_free'] == 'yes') {
                                    $price = 'Free Benefit';
                                } else {
                                    if ($benefit['benefit_mode'] == 'rate') {
                                        $price = $benefit['benefit_rate'] .  "% of Premium";
                                    } else {
                                        $price = 'Ksh. ' . $benefit['benefit_price'];
                                    }
                                }

                            ?>

                                <div class="row">
                                    <div class="col-6">
                                        <p class="LeftSideText"><?= $benefit['benefit_name'] ?></p>
                                    </div>
                                    <div class="col-6">
                                        <p class="RightSideText"><?= $price ?></p>
                                    </div>

                                </div>

                            <?php
                            }
                        } else { ?>
                            <div class="row">
                                <div class="col-6">
                                    <p class="LeftSideText">Cover Duration</p>
                                </div>
                                <div class="col-6">
                                    <p class="RightSideText"><?= $policy['cover_duration'] . " Month" . ($policy['cover_duration'] == '1' ? '' : 's')   ?> </p>
                                </div>
                            </div>
                        <?php

                        }

                        ?>


                        <hr class="rounded">


                        <div class="row">
                            <div class="col-6">
                                <p class="LeftSideText">TOTAL</p>
                            </div>
                            <div class="col-6">
                                <p class="RightSideText"><?= "Ksh. " . $newPrice ?></p>
                            </div>
                        </div>


                        <div class="DivBottom">
                            <input type="button" id="BtnBook" class="InputBtn nir-btn mt-1" value="Pay" />
                            <div class="spin" style="display:none" id="spin"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- End of About section
	============================================= -->
<script>
    $(document).ready(function() {
        const progressBar = document.getElementById("progress-bar");
        const progressNext = document.getElementById("progress-next");
        const progressPrev = document.getElementById("progress-prev");
        const steps = document.querySelectorAll(".step");
        let active = 1;



        progressNext.addEventListener("click", () => {
            active++;
            if (active > steps.length) {
                active = steps.length;
            }
            updateProgress();
        });

        progressPrev.addEventListener("click", () => {
            active--;
            if (active < 1) {
                active = 1;
            }
            updateProgress();
        });

        const updateProgress = () => {
            steps.forEach((step, i) => {
                if (i < active) {
                    step.classList.add("active");
                } else {
                    step.classList.remove("active");
                }
            });
            progressBar.style.width = ((active - 1) / (steps.length - 1)) * 100 + "%";
            if (active === 1) {
                progressPrev.disabled = true;
            } else if (active === steps.length) {
                progressNext.disabled = true;
            } else {
                progressPrev.disabled = false;
                progressNext.disabled = false;
            }
            console.log(active);
            if (active == 3) {
                $('#personal_form').css('display', 'none');
                $('#vehicle_form').css('display', 'none');
            }
            if (active == 2) {
                $('#personal_form').css('display', 'none');
                $('#vehicle_form').css('display', 'flex');
            }
            if (active == 1) {
                $('#personal_form').css('display', 'flex');
                $('#vehicle_form').css('display', 'none');
            }
        };




        $('#BtnBook').click(function() {
            // Trigger form submission if the form is valid
            if ($('#MyForm')[0].checkValidity()) {
                $('#BtnBook').hide();
                $('#spin').show();

                var formData = new FormData();

                // Loop through each input field inside the personal_form div
                $('.PersVeh input, .PersVeh select').each(function() {
                    var inputName = $(this).attr('name');
                    var inputValue = $(this).val();
                    formData.append('newPrice', '<?= $newPrice ?>');

                    // If it's a file input, handle it differently
                    if ($(this).attr('type') === 'file') {
                        var fileInput = $(this)[0].files[0]; // Get the file object
                        // Append the file to FormData
                        if (fileInput) {
                            formData.append(inputName, fileInput);
                        }
                    } else {
                        // For other input types, add to FormData normally
                        if (inputName) {
                            formData.append(inputName, inputValue);
                        }
                    }
                });

                if ($('#Name').val() != '') {
                    $.ajax({
                        url: "model/update/send_to_db.php",
                        type: "POST",
                        data: formData,
                        processData: false, // Important: prevent jQuery from automatically processing the data
                        contentType: false, // Important: prevent jQuery from setting contentType
                        success: function(response) {
                            console.log(response);
                            var data = JSON.parse(response);

                            if (data.data == 1) {
                                //var token = data.token;
                                var checksum = data.checksum;
                                var amount = data.amount;
                                var email = data.email;
                                var rand = data.rand;
                                var phone = data.phone;
                                var token = data.token;
                                var bid = data.bid;

                                const cred = {
                                    token: token
                                }
                                const checkoutDetails = {
                                    OrderId: rand,
                                    CustomerEmail: email,
                                    Currency: 'KES',
                                    CustomerPhone: phone,
                                    OrderAmount: amount,
                                    BusinessEmail: 'anga.managers@gmail.com',
                                    CancelledUrl: 'https://jambosure.com/info.php',
                                    CallBackUrl: 'https://jambosure.com/success.php?bid=' + bid,
                                    Description: "transaction description",
                                    ClientKey: "82d0c8f77f85420f8bc141269850b5395ec462114c9f431e8c509df9809d0789634ebf20a5774ec99fa4712241691dd9",
                                    SupportEmail: "info@angacinemas.com",
                                    SupportPhone: "0712345678",
                                    UseJPLogo: "yes",
                                    StoreName: "Anga cinemas"
                                }
                                jambopayCheckout(checkoutDetails);
                            } else {
                                // Handle other responses
                                alert(data.data);
                            }
                        }
                    });

                } else {
                    alert('You need to fill all the fields');
                    $('#BtnBook').show();
                    $('#spin').hide();
                }
            } else {
                // If form is not valid, display error messages or handle as necessary
                alert('Please fill in all required fields.');
            }
        });



    });
</script>

<style>
    #vehicle_form {
        display: none;
    }


    #progress {
        position: relative;
        margin-bottom: 30px;
    }

    #progress-bar {
        position: absolute;
        background: <?= $maincolor ?>;
        height: 5px;
        width: 0%;
        top: 50%;
        left: 0;
    }

    #progress-num {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        justify-content: space-between;
    }

    #progress-num::before {
        content: "";
        background-color: lightgray;
        position: absolute;
        top: 50%;
        left: 0;
        height: 5px;
        width: 100%;
        z-index: 1;
    }

    #progress-num .step {
        border: 3px solid lightgray;
        border-radius: 100%;
        width: 4em;
        height: 4em;
        line-height: 25px;
        text-align: center;
        background-color: #fff;
        font-size: 14px;
        position: relative;
        z-index: 1;
    }

    #progress-num .step.active {
        border-color: <?= $maincolor ?>;
        background-color: <?= $maincolor ?>;
        color: #fff;
    }

    .btn {
        background: lightgray;
        border: none;
        border-radius: 3px;
        padding: 6px 12px;
    }

    input[type="file"] {
        display: none;
    }

    .custom-file-upload {
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
        width: 100%;
        margin: 10px 0em;
        height: 3em;
    }

    .LeftSideText {
        font-weight: bold;
    }

    /* Rounded border */
    hr.rounded {
        border-top: 8px solid #bbb;
        border-radius: 5px;
    }
</style>


<?php include_once 'footer.php'; ?>