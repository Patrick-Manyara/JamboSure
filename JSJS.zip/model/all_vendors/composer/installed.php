<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'dompdf/dompdf' => 
    array (
      'pretty_version' => 'v1.0.2',
      'version' => '1.0.2.0',
      'aliases' => 
      array (
      ),
      'reference' => '8768448244967a46d6e67b891d30878e0e15d25c',
    ),
    'phenx/php-font-lib' => 
    array (
      'pretty_version' => '0.5.2',
      'version' => '0.5.2.0',
      'aliases' => 
      array (
      ),
      'reference' => 'ca6ad461f032145fff5971b5985e5af9e7fa88d8',
    ),
    'phenx/php-svg-lib' => 
    array (
      'pretty_version' => 'v0.3.3',
      'version' => '0.3.3.0',
      'aliases' => 
      array (
      ),
      'reference' => '5fa61b65e612ce1ae15f69b3d223cb14ecc60e32',
    ),
    'phpmailer/phpmailer' => 
    array (
      'pretty_version' => 'v6.5.1',
      'version' => '6.5.1.0',
      'aliases' => 
      array (
      ),
      'reference' => 'dd803df5ad7492e1b40637f7ebd258fee5ca7355',
    ),
    'sabberworm/php-css-parser' => 
    array (
      'pretty_version' => '8.3.1',
      'version' => '8.3.1.0',
      'aliases' => 
      array (
      ),
      'reference' => 'd217848e1396ef962fb1997cf3e2421acba7f796',
    ),
    'tecnickcom/tc-lib-barcode' => 
    array (
      'pretty_version' => '1.15.4',
      'version' => '1.15.4.0',
      'aliases' => 
      array (
      ),
      'reference' => '34b0224f71ebfe83adcef9f14f3d81965fb55493',
    ),
    'tecnickcom/tc-lib-color' => 
    array (
      'pretty_version' => '1.14.6',
      'version' => '1.14.6.0',
      'aliases' => 
      array (
      ),
      'reference' => '83cdb57fd900901c6aa2af8cfd67202518fb69b2',
    ),
  ),
);
