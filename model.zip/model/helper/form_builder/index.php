<?php

define('FORM_PATH', realpath(dirname(__FILE__)) . '/');

require_once FORM_PATH . 'input.php';
require_once FORM_PATH . 'submit.php';
require_once FORM_PATH . 'textarea.php';
require_once FORM_PATH . 'dropdown.php';
require_once FORM_PATH . 'checkbox.php';