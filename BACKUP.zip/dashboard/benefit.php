<?php
$page        = 'product';
require_once 'header.php';

$current_year   = date("Y");

$benefit = get_by_id('benefit', security('id', 'GET'));

if (!empty($benefit)) {
    session_assignment(array(
        'edit' => $benefit['benefit_id']
    ), false);
    $require = false;
} else {
    $required = true;
}


?>
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body card-secondary">
            <div class="card-header">
                <h3 class="card-title">Edit benefit </h3>
            </div>
            <div class="mt-4">
                <form enctype="multipart/form-data" action="<?= model_url ?>simple&table=benefit&url=product_details?id=<?= $_GET['pid'] ?>" method="POST">
                    <div class="row clearfix">

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php
                            input_hybrid('benefit Name', 'benefit_name', $benefit, $require);

                            ?>
                            <input hidden name="product_id" value="<?= security('pid','GET') ?>" />
                            <div class="col-lg-12 col-md-6 col-sm-12 col-xs-6">
                                <?php
                                input_select('Free', 'benefit_free', $benefit, false, array('yes', 'no'))
                                ?>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-12 col-xs-6">
                                <?php
                                input_select('Rate or Block Figure', 'benefit_mode', $benefit, false, array('price', 'rate'))
                                ?>
                            </div>

                            <div id="prodmode">
                                <?php
                                input_hybrid('benefit_rate', 'benefit_rate', $benefit, false, "number");
                                input_hybrid('benefit_price', 'benefit_price', $benefit, false, "number");
                                input_hybrid('benefit_mincap', 'benefit_code', $benefit, false, "number");
                                ?>
                            </div>





                        </div>

                   

                    </div>




                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-4 text-center">
                        <div class="text-center">
                            <button class="btn btn-primary" type="submit" id="submit">Edit</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<!-- End of Main Content -->



<?php include_once 'footer.php'; ?>