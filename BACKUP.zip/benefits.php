<?php
$page = 'benefits';
include_once 'header.php';
// cout($_POST);

$sql = "SELECT * FROM product WHERE category_id = '$_POST[category_id]' AND subcategory_id = '$_POST[subcategory_id]' ";
$cats = select_rows($sql);
?>


<!-- Start of breadcrumb section
	============================================= -->
<section id="in-breadcrumb" class="in-breadcrumb-section">
    <div class="in-breadcrumb-content position-relative" data-background="assets/img/new/header.png">
        <div class="background_overlay"></div>
        <div class="container">
            <div class="in-breadcrumb-title-content position-relative headline ul-li">
                <span> </span>
                <h2>Home / <?= ucwords($page) ?></h2>
            </div>
        </div>
    </div>
</section>


<section id="in-about-1" class="in-about-section-1 about-page-about position-relative">
    <div class="container">
        <div class="DeeStart">
            <h2 class="AboutHeader">
                Motor comprehensive Insurance
            </h2>
        </div>
        <div class="InsuranceHeader">
            <div class="InsuranceHeaderTop">
                <div class="InsurancerTop">
                    <h3>
                        Make
                    </h3>
                    <h3>
                        Model
                    </h3>
                    <h3>
                        Year
                    </h3>
                    <h3>
                        Amount
                    </h3>
                    <h3>
                        Cover Duration
                    </h3>
                </div>
            </div>
            <div class="InsuranceHeaderBottom">
                <div class="InsurancerBottom">
                    <h3>
                        <?= $_POST['make'] ?>
                    </h3>
                    <h3>
                        <?= $_POST['model'] ?>

                    </h3>
                    <h3>
                        <?= $_POST['year'] ?>

                    </h3>
                    <h3>
                        <?= $_POST['value'] ?>

                    </h3>
                    <h3 style="display: inline-flex;">
                        <?= $_POST['cover_duration'] ?>
                        months <i id="pencil" class="fas fa-pen"></i>
                    </h3>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="DeeStart">
            <h2 class="AboutHeader">
                Quotes Available
            </h2>
        </div>


        <div class="col-lg-12 mb-4">
            <?php
            if (!empty($cats)) {
                foreach ($cats as $product) {
                    $sql33 = "SELECT * FROM benefit WHERE product_id = '$product[product_id]' AND benefit_free = 'no' ";
                    $benefits       = select_rows($sql33);

                    $sql22 = "SELECT * FROM benefit WHERE product_id = '$product[product_id]' AND benefit_free = 'yes' ";
                    $free_benefits = select_rows($sql22);

                    $levies       = get_by_column('levy', 'product_id', $product['product_id']);


                    if ($product['product_mode'] == 'rate') {
                        $price = ($product['product_rate'] / 100 * security('value'));
                    } else {
                        $price = $product['product_price'];
                    }
            ?>
                    <form enctype="multipart/form-data" action="<?= model_url ?>policy" method="POST">


                        <?php
                        if (isset($_POST['make'])) {
                            foreach ($_POST as $key => $value) {
                        ?>
                                <input hidden name="<?= $key ?>" value="<?= $value ?>" />
                        <?php
                            }
                        }

                        ?>

                        <div class="QuotesCard">
                            <div class="QuotesInner">
                                <div class="SingleQuote">
                                    <div class="SingleQuoteContent">
                                        <div class="row">
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote">
                                                <img src="<?= file_url . get_by_id('writer', $product['writer_id'])['writer_image'] ?>" style="width:100px; height:auto; border-radius:5px;" title="<?= $product['product_name'] ?>" />

                                            </div>
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote">
                                                <?= $product['product_name']  ?>
                                            </div>
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote">
                                                <p>
                                                    <b>
                                                        Ksh. <?= $price  ?>
                                                    </b>
                                                </p>
                                            </div>
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote">
                                                <button class="InputBtnClear" id="benefitBtn<?= $product['product_id'] ?>" type="button">
                                                    Add Benefits
                                                </button>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>

                        <input hidden name="price" value="<?= $price  ?>" />

                        <input hidden name="product_id" value="<?= $product['product_id'] ?>" />

                        <div style="display: none;" id="BenefitsDiv<?= $product['product_id'] ?>">

                            <div class="DeeStart">
                                <h2 class="AboutHeader">
                                    Cover Details
                                </h2>
                            </div>

                            <div class="CoversCard">
                                <div class="QuotesInner">
                                    <div class="SingleBenefit">
                                        <div class="SingleQuoteContent">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-12 col-12 ContentQuote">
                                                    <p style="color:white;">
                                                        <b>
                                                            Optional Benefits
                                                        </b>
                                                    </p>
                                                </div>
                                                <div class="col-lg-6 col-sm-12 col-12 ContentQuote">
                                                    <p style="color:white;">
                                                        <b>
                                                            Amount
                                                        </b>
                                                    </p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                </div>
                            </div>

                            <?php
                            foreach ($benefits as $ben) {
                                if ($ben['benefit_mode'] == 'rate') {
                                    $price = $ben['benefit_rate'] .  "% of Value";
                                } else {
                                    $price = 'Ksh. ' . $ben['benefit_price'];
                                }
                            ?>

                                <div class="SingleCover">
                                    <div class="SingleQuoteContent">
                                        <div class="row">
                                            <div class="col-lg-6 col-sm-12 col-12 ContentQuote">
                                                <p>
                                                    <b>
                                                        <?= $ben['benefit_name']   ?>
                                                    </b>
                                                </p>
                                            </div>
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote">
                                                <p>
                                                    <b>
                                                        Ksh. <?= $price  ?>
                                                    </b>
                                                </p>
                                            </div>
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote custom-checkbox">
                                                <input class="form-check-input" name="benefits[]" type="checkbox" value="<?= $ben['benefit_id'] ?>" />
                                                <label for="checkbox1">Add</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            <?php
                            }
                            ?>




                            <div class="CoversCard">
                                <div class="QuotesInner">
                                    <div class="SingleBenefit">
                                        <div class="SingleQuoteContent">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-12 col-12 ContentQuote">
                                                    <p style="color:white;">
                                                        <b>
                                                            Benefits
                                                        </b>
                                                    </p>
                                                </div>
                                                <div class="col-lg-6 col-sm-12 col-12 ContentQuote">
                                                    <p style="color:white;">
                                                        <b>
                                                            Amount
                                                        </b>
                                                    </p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                </div>
                            </div>

                            <?php
                            foreach ($free_benefits as $free_ben) {
                                if ($free_ben['benefit_mode'] == 'rate') {
                                    $free_price = $free_ben['benefit_rate'] .  "% of Value";
                                } else {
                                    $free_price = 'Ksh. ' . $free_ben['benefit_price'];
                                }
                            ?>



                                <div class="SingleCover">
                                    <div class="SingleQuoteContent">
                                        <div class="row">
                                            <div class="col-lg-6 col-sm-12 col-12 ContentQuote">
                                                <p>
                                                    <b>
                                                        <?= $free_ben['benefit_name']   ?>
                                                    </b>
                                                </p>
                                            </div>
                                            <div class="col-lg-3 col-sm-12 col-12 ContentQuote">
                                                <p>
                                                    <b>
                                                        <?= $free_price ?>
                                                    </b>
                                                </p>
                                            </div>

                                        </div>
                                    </div>
                                </div>



                            <?php
                            }
                            ?>









                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-4 text-center mt-4">
                                <div class="text-center">
                                    <button class="btn btn-primary" type="submit" id="submit">Submit</button>
                                </div>
                            </div>
                        </div>

                    </form>
            <?php
                }
            }

            ?>



        </div>

    </div>
</section>

<div class="modal wow fadeInDown" tabindex="-1" role="dialog" id="myModal2">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">

                <h3 class="GreenHeader MarginBottom" style="font-size: 20px;">
                    Edit Details
                </h3>
                <button type="button" class="close myClose2" data-dismiss="modal" aria-label="Close">
                    X
                </button>
            </div>
            <div class="modal-body">

                <div class="ModalBodyInner">



                    <div class="ModalForms">

                        <div id="PrivateForm">
                            <form method="POST" action="benefits.php">
                                <div class="row">
                                    <div class="DeeFlex" style="width: 100%;">
                                        <div style="width:30%;height: 100%;">
                                            <p class="DeeFlex" style="height: 100%;">
                                                <b>
                                                    Make
                                                </b>
                                            </p>
                                        </div>
                                        <div style="width:70%">
                                            <div class="form-group ModalFormInput">
                                                <input type="text" class="form-control" value="<?= security('make') ?>" name="make" placeholder="Enter Make" aria-label="Enter Make">
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                <div class="row">
                                    <div class="DeeFlex" style="width: 100%;">
                                        <div style="width:30%;height: 100%;">
                                            <p class="DeeFlex" style="height: 100%;">
                                                <b>
                                                    Model
                                                </b>
                                            </p>
                                        </div>
                                        <div style="width:70%">
                                            <div class="form-group ModalFormInput">
                                                <input type="text" class="form-control" value="<?= security('model') ?>" name="model" placeholder="Enter Model" aria-label="Enter Make">
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                <div class="row">
                                    <div class="DeeFlex" style="width: 100%;">
                                        <div style="width:30%;height: 100%;">
                                            <p class="DeeFlex" style="height: 100%;">
                                                <b>
                                                    Year of Manufacture
                                                </b>
                                            </p>
                                        </div>
                                        <div style="width:70%">
                                            <div class="form-group ModalFormInput">
                                                <input type="number" class="form-control" value="<?= security('year') ?>" name="year" placeholder="Enter Year of Manufacture" aria-label="Enter Make">
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                <div class="row">
                                    <div class="DeeFlex" style="width: 100%;">
                                        <div style="width:30%;height: 100%;">
                                            <p class="DeeFlex" style="height: 100%;">
                                                <b>
                                                    Estimated value
                                                </b>
                                            </p>
                                        </div>
                                        <div style="width:70%">
                                            <div class="form-group ModalFormInput">
                                                <input type="number" class="form-control" value="<?= security('value') ?>" name="value" placeholder="Enter Amount Insured" aria-label="Enter Estimated value in Ksh">
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="row">
                                    <div class="DeeFlex" style="width: 100%;">
                                        <div style="width:30%;height: 100%;">
                                            <p class="DeeFlex" style="height: 100%;">
                                                <b>
                                                    Cover Duration
                                                </b>
                                            </p>
                                        </div>
                                        <div style="width:70%">
                                            <div class="form-group ModalFormInput">
                                                <select class="form-select fom-control" name="cover_duration" aria-label="Default select example">
                                                    <option selected>Cover Duration</option>
                                                    <option value="1">1 month</option>
                                                    <option value="12">12 months</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="DeeFlex MarginTop">
                                    <button type="submit" class="InputBtn">
                                        Get A Quote
                                    </button>
                                </div>
                            </form>
                        </div>



                        <div id="CommercialForm">
                            <div class="FormText">
                                <p>Commercial</p>
                            </div>
                            <form>
                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Cover Duration</option>
                                                <option value="1">1 month</option>
                                                <option value="2">6 months</option>
                                                <option value="3">12 months</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Make</option>
                                                <option value="1">BMW</option>
                                                <option value="2">Audi</option>
                                                <option value="3">Mazda</option>
                                                <option value="3">Toyota</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Model</option>
                                                <option value="1">116</option>
                                                <option value="2">216</option>
                                                <option value="3">318</option>
                                                <option value="3">320</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <div class="form-group ModalFormInput">
                                                <input type="text" onfocus="(this.type='date')" class="form-control" placeholder="Year" aria-label="Year">
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Covered Person</option>
                                                <option value="1">Individual</option>
                                                <option value="2">Business</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Type of Vehicle</option>
                                                <option value="1">Saloon</option>
                                                <option value="2">Three Wheeler</option>
                                                <option value="3">Four Wheeler</option>
                                                <option value="3">Toyota</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Use of Vehicle</option>
                                                <option value="1">Individual</option>
                                                <option value="2">Business</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Tonnage</option>
                                                <option value="1">1 Tonne</option>
                                                <option value="2">2 Tonnes</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <input type="text" class="form-control" placeholder="Estimated value in Ksh" aria-label="Estimated value in Ksh">
                                        </div>

                                    </div>
                                </div>
                                <div class="DeeFlex MarginTop">
                                    <a class="InputBtn" href="benefits.php">
                                        Get A Quote
                                    </a>
                                </div>
                            </form>
                        </div>

                        <div id="PSVForm">
                            <div class="FormText">
                                <p>PSV</p>
                            </div>
                            <form>
                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Cover Duration</option>
                                                <option value="1">1 month</option>
                                                <option value="2">6 months</option>
                                                <option value="3">12 months</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Make</option>
                                                <option value="1">BMW</option>
                                                <option value="2">Audi</option>
                                                <option value="3">Mazda</option>
                                                <option value="3">Toyota</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Model</option>
                                                <option value="1">116</option>
                                                <option value="2">216</option>
                                                <option value="3">318</option>
                                                <option value="3">320</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <div class="form-group ModalFormInput">
                                                <input type="text" onfocus="(this.type='date')" class="form-control" placeholder="Year" aria-label="Year">
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Covered Person</option>
                                                <option value="1">Individual</option>
                                                <option value="2">Business</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Type of Vehicle</option>
                                                <option value="1">Saloon</option>
                                                <option value="2">Three Wheeler</option>
                                                <option value="3">Four Wheeler</option>
                                                <option value="3">Toyota</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Use of Vehicle</option>
                                                <option value="1">Individual</option>
                                                <option value="2">Business</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-lg-6 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <select class="form-select fom-control" aria-label="Default select example">
                                                <option selected>Tonnage</option>
                                                <option value="1">1 Tonne</option>
                                                <option value="2">2 Tonnes</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-12">
                                        <div class="form-group ModalFormInput">
                                            <input type="text" class="form-control" placeholder="Estimated value in Ksh" aria-label="Estimated value in Ksh">
                                        </div>

                                    </div>
                                </div>
                                <div class="DeeFlex MarginTop">
                                    <a class="InputBtn" href="benefits.php">
                                        Get A Quote
                                    </a>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>

            </div>
            <!-- <div class="modal-footer">

                <button type="button" class="btn btn-secondary myClose2" data-dismiss="modal">Close</button>
            </div> -->
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#pencil').click(function() {
            $('#myModal2').modal('show');
        });

        $('.myClose2').click(function() {
            $('#myModal2').modal('hide');
        });

        var SelectedValue;
        <?php
        if (!empty($cats)) {
            foreach ($cats as $item) {
        ?>
                $('#benefitBtn<?= $item['product_id'] ?>').click(function() {
                    // Hide all elements with BenefitsDiv class
                    $('[id^=BenefitsDiv]').css('display', 'none');

                    // Show the clicked element
                    $('#BenefitsDiv<?= $item['product_id'] ?>').css('display', 'block');
                });
        <?php
            }
        }
        ?>
    });
</script>
<?php include_once 'footer.php'; ?>