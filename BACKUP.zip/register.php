<?php
$page = 'create account';
include_once 'header.php';
?>


<section id="in-breadcrumb" class="in-breadcrumb-section">
    <div class="in-breadcrumb-content position-relative" data-background="assets/img/new/header.png">
        <div class="background_overlay"></div>
        <div class="container">
            <div class="in-breadcrumb-title-content position-relative headline ul-li">
                <span> </span>
                <h2>Home / <?= ucwords($page) ?></h2>
            </div>
        </div>
    </div>
</section>


<section id="in-about-1" class="in-about-section-1 about-page-about position-relative">
    <div class="container">
        <div class="DeeFlex">
            <div class="QuotesCard2">
                <div class="DeeFlex">

                    <div class="QuotesInner2">
                        <h2>
                            Create Account
                        </h2>
                        <p>
                            In order to create an account please fill in the details below
                        </p>
                        <form method="POST" action="<?= model_url ?>register<?= isset($_GET['payment']) ? '&payment' : '' ?>">
                            <div class="LoginInputs">
                                <div class="form-group">
                                    <input type="text" required placeholder="Full Name" name="user_name" class="LoginInput" />
                                </div>
                                <div class="form-group">
                                    <input type="text" required placeholder="Phone Number"  name="user_phone" class="LoginInput" />
                                </div>
                                <div class="form-group">
                                    <input type="email" required placeholder="Email Address"  name="user_email" class="LoginInput" />
                                </div>
                                <div class="form-group">
                                    <select  name="user_type" class="form-select form-control LoginInput" aria-label="Default select example" id="client_type">
                                        <option selected>Inidividual or Businness</option>
                                        <option value="individual">Inidividual</option>
                                        <option value="business">Businness</option>
                                    </select>
                                </div>
                                <div class="form-group" id="business_input">
                                    <input type="text"  name="business_name" placeholder="Business Name" class="LoginInput" />
                                </div>
                                <div class="form-group">
                                    <input type="password" required  name="user_password" placeholder="Password" class="LoginInput" />
                                </div>
                                <div class="form-group">
                                    <input type="password" required name="confirm_password" placeholder="Confirm Password" class="LoginInput" />
                                </div>
                                <div class="JusAround">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            I agree to <a href="#" style="color:<?= $maincolor ?>"> Terms of Service </a>and <a href="#" style="color:<?= $maincolor ?>"> Privacy Policy</a> .
                                        </label>
                                    </div>
                                </div>

                                <div class="MarginTop">
                                    <button type="submit" class="BlueBtn">
                                        Continue
                                    </button>
                                </div>

                                <div class="DeeFlex MarginTop">

                                    <a href="login.php">
                                        Have an account already?
                                        <span style="color:<?= $maincolor ?>;">
                                            Login
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of About section
	============================================= -->
<script>
    $(document).ready(function() {
        $('#client_type').change(function() {
            var selected_value = $(this).val();
            if (selected_value == 'business') {
                $('#business_input').css('display', 'none');
            }
            if (selected_value == 'business') {
                $('#business_input').css('display', 'block');
            }
            if (selected_value == 'individual') {
                $('#business_input').css('display', 'none');
            }
        });
    });
</script>


<?php include_once 'footer.php'; ?>